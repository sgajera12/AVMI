from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='lidarcam',
            executable='live_fusion',
            name='live_fusion',
            output='screen',
            parameters=[{
                'base_dir': '/home/pinaka/dataset/rellis3d/Rellis-3D',
                'sequence': '00000',
                'rate_hz': 10.0,
                'image_topic': '/camera/image_raw',
                'lidar_topic': '/lidar/points',
                'fusion_topic': '/fusion/projected_image',
            }]
        )
    ])
